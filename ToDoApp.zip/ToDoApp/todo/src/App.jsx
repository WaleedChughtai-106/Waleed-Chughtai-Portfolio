import React from "react";
import ToDo from "./Components/ToDo";

const App = () => {
  return (
    <div>
      <ToDo />
    </div>
  );
};

export default App;
