import React from "react";
import "./TaskCompletion.css";
const TasksCompletion = (props) => {
  const { completeTasks, remaningTasks, TotalTasks } = props;
  return (
    <div>
      <section className="TaskCompletionSection">
        <div className="TaskCompletionContent">
          <div className="CompletionRemainingContent">
            <h2>Task Completed</h2>
            <div>{`${completeTasks} / ${TotalTasks}`}</div>
          </div>
          <div className="CompletionRemainingContent">
            <h2>Tasks Remaining</h2>
            <div>{`${remaningTasks} / ${TotalTasks}`}</div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TasksCompletion;
