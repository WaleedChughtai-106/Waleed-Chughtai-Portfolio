import React, { useEffect, useRef, useState } from "react";
import TodoCss from "./Todo.module.css";
import TasksCompletion from "./TasksCompletion";

const ToDo = () => {
  const [TotalTasks, setTotalTasks] = useState(0);
  const [TaskInput, setTaskInput] = useState("");
  const [completedTasks, setCompletedTasks] = useState(0);
  const [remainingTasks, setRemainingTasks] = useState(0);
  const todoData = JSON.parse(localStorage.getItem("todo_Items")) || [];
  const [allTodoData, setAllToDoData] = useState(todoData);

  const darkMode = useRef();
  const toggleMode = useRef();
  function handleForm(e) {
    e.preventDefault();
    if (!TaskInput) {
      alert("Please add a task!");
    } else {
      let isverified = allTodoData.some((value, index) => {
        return value.todoTask.toLowerCase() === TaskInput.toLowerCase();
      });
      if (isverified) {
        alert("Task already added!");
        setTaskInput("");
      } else {
        setAllToDoData([
          ...allTodoData,
          { todoTask: TaskInput, complete: false },
        ]);
        setTaskInput("");
      }
    }
    // console.log({ task: TaskInput });
  }
  function handleCheck(id) {
    // console.log(id);
    const copyOfAllToDoTasks = [...allTodoData];
    copyOfAllToDoTasks[id].complete = !copyOfAllToDoTasks[id].complete;
    setAllToDoData(copyOfAllToDoTasks);

    console.log(TotalTasks);
  }

  function handleDelete(id) {
    const copyOfAllToDoTasks = [...allTodoData];
    const filteredValues = copyOfAllToDoTasks.filter((value, index) => {
      return index !== id;
    });
    // console.log(filteredValues);
    setAllToDoData(filteredValues);
  }

  function handleUpdate(id) {
    const copyOfAllToDoTasks = [...allTodoData];
    let toUpdateTask = allTodoData[id].todoTask;
    let newCurrentUpdatedTask = prompt(
      `Update task: =${toUpdateTask}`,
      toUpdateTask
    );
    let newObj = { todoTask: newCurrentUpdatedTask, complete: false };
    copyOfAllToDoTasks.splice(id, 1, newObj);

    setAllToDoData(copyOfAllToDoTasks);
  }
  function handleDarkMode() {
    const element = darkMode.current;
    const currentBg = window.getComputedStyle(element).backgroundColor; // Get actual bg color

    if (currentBg === "rgb(255, 255, 255)" || currentBg === "") {
      element.style.backgroundColor = "#121212";
      element.style.color = "#E0E0E0";
      toggleMode.current.className = "bi bi-toggle-on";
    } else {
      element.style.backgroundColor = "#ffffff";
      element.style.color = "#2d2d2d";
      toggleMode.current.className = "bi bi-toggle-off";
    }
  }

  useEffect(() => {
    const copyOfAllToDoTasks = [...allTodoData];
    let completedTasks = copyOfAllToDoTasks.filter((value, index) => {
      return value.complete;
    });
    let remainingTasks = copyOfAllToDoTasks.filter((value, index) => {
      return value.complete === false;
    });
    let TotalTasks = copyOfAllToDoTasks.filter((value, index) => {
      return value;
    });

    setCompletedTasks(completedTasks.length);
    setRemainingTasks(remainingTasks.length);
    setTotalTasks(TotalTasks.length);
    localStorage.setItem("todo_Items", JSON.stringify(copyOfAllToDoTasks));
  }, [allTodoData]);
  return (
    <div>
      <div className={TodoCss.main}>
        <div className={TodoCss.todoApp} ref={darkMode}>
          <h1 className={TodoCss.appHeading}>
            ToDo Application{" "}
            <i
              className="bi bi-toggle-off"
              ref={toggleMode}
              onClick={handleDarkMode}
            ></i>
          </h1>
          {allTodoData.length > 0 && (
            <TasksCompletion
              completeTasks={completedTasks}
              remaningTasks={remainingTasks}
              TotalTasks={TotalTasks}
            />
          )}

          <form className={TodoCss.appForm} action="" onSubmit={handleForm}>
            <div className={TodoCss.taskEntryAndSubmitContainer}>
              <input
                className={TodoCss.inputBox}
                type="text"
                name=""
                id=""
                placeholder="Enter Your Task"
                value={TaskInput}
                onChange={(e) => {
                  setTaskInput(e.target.value);
                }}
              />
              <input
                className={TodoCss.btn}
                type="submit"
                name=""
                id=""
                value="Add Task"
              />
            </div>

            {allTodoData.length === 0 ? (
              <h5 style={{ textAlign: "center" }}>No Tasks Added!</h5>
            ) : (
              allTodoData.map((items, index) => (
                <ul className={TodoCss.taskList} key={index}>
                  <div className={TodoCss.taskListItem}>
                    <div className={TodoCss.checkBox_Item}>
                      <input
                        type="checkbox"
                        checked={items.complete}
                        onClick={() => {
                          handleCheck(index);
                        }}
                      />
                      <span
                        className={TodoCss.textItems}
                        style={{
                          textDecoration: items.complete ? "line-through" : "",
                        }}
                      >
                        {items.todoTask}
                      </span>
                    </div>

                    <div className={TodoCss.editIconsContainer}>
                      <div className={TodoCss.editIconsHover}>
                        <i
                          class="bi bi-pencil-square editIconsHover"
                          onClick={() => {
                            handleUpdate(index);
                          }}
                        ></i>
                      </div>
                      <div className={TodoCss.editIconsHover}>
                        <i
                          className="bi bi-trash3 editIconsHover"
                          onClick={() => {
                            handleDelete(index);
                          }}
                        ></i>
                      </div>
                    </div>
                  </div>
                </ul>
              ))
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default ToDo;
